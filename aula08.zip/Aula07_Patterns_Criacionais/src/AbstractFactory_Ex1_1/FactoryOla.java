package AbstractFactory_Ex1_1;


public interface FactoryOla {
	Ola criarOla();

	void outOla();
}
