package AbstractFactory_Ex1_1;

import java.io.PrintStream;


public class Ola {
	String mensagem;

	public Ola(PrintStream printStream) {
	
	}

	public Ola() {
		
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	
	


}
