package FactoryMethod_Ex2_1;

public abstract class Nome {
	public String nome;
	public String sobrenome;
}
