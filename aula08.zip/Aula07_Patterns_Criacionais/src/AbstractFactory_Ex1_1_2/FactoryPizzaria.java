package AbstractFactory_Ex1_1_2;

public interface FactoryPizzaria {
	String funcionarioP();
	String funcionarioS();
}
