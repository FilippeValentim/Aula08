package AbstractFactory_Ex1_1_2;

public class Pizzaria {
	String data;

}
