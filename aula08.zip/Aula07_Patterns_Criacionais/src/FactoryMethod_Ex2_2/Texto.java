package FactoryMethod_Ex2_2;

public abstract class Texto {
	public String texto;

}
