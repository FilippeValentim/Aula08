package FactoryMethod_Ex2_3;

public class Num extends Numero{
	
	public Num(int num){
		this.num = num;
	}

}
