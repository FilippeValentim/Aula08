package FactoryMethod_Ex2_3;

public abstract class Numero {
	public int num;
}
